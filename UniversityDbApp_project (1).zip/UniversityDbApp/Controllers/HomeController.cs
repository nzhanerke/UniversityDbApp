using Microsoft.AspNetCore.Mvc;

namespace UniversityDbApp.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();
    public IActionResult Error() => Content("Қате орын алды. SQL Server қосылымын тексеріңіз.");
}
