using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityDbApp.Data;

namespace UniversityDbApp.Controllers;

public class DepartmentsController : Controller
{
    private readonly AppDbContext _db;
    public DepartmentsController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index() =>
        View(await _db.Departments.AsNoTracking().OrderBy(d => d.Name).ToListAsync());
}
