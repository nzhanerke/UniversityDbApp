using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityDbApp.Data;

namespace UniversityDbApp.Controllers;

public class TeachersController : Controller
{
    private readonly AppDbContext _db;
    public TeachersController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index() =>
        View(await _db.Teachers.AsNoTracking().Include(t => t.Department)
            .OrderBy(t => t.FullName).ToListAsync());
}
