# UniversityDbApp — 3-апта

ASP.NET Core MVC (.NET 8) + EF Core + SQL Server. `Department` (1) — `Teacher` (көп).

## Алдын ала қажет
- Windows жүйесі, .NET 8 SDK, Visual Studio (ASP.NET and web development) немесе VS Code
- SQL Server Express LocalDB (`(localdb)\MSSQLLocalDB`) немесе SQL Server
- EF Core 8 CLI/Package Manager Console

## Іске қосу
1. `UniversityDbApp.csproj` файлын Visual Studio-да ашыңыз.
2. `appsettings.json` ішіндегі `DefaultConnection` SQL Server-ге сай келетінін тексеріңіз. LocalDB болмаса, өз серверіңізге бейімдеңіз.
3. **Ескерту:** `Migrations` қалтасында `InitialDb` миграциясының бастапқы коды берілген; **екінші рет `Add-Migration InitialDb` жасамаңыз.** Оны нақты жоба ішінде өзіңіз генерациялағыңыз келсе, `Migrations` қалтасын алдымен алып тастаңыз.
4. Visual Studio > Tools > NuGet Package Manager > Package Manager Console: `Update-Database`.
5. `F5` немесе терминалда `dotnet run`.

### Migration-ды нөлден құру керек болса
`Migrations` қалтасын жойып, Package Manager Console ішінде:
```powershell
Add-Migration InitialDb
Update-Database
```
Немесе терминалда:
```bash
dotnet tool install --global dotnet-ef --version 8.0.11
dotnet ef migrations add InitialDb
dotnet ef database update
```

## Скриншот
SSMS ішінде серверге қосылыңыз → Databases → UniversityDb → Tables. Көрінуі тиіс: `dbo.Departments`, `dbo.Teachers`, `dbo.__EFMigrationsHistory`. Нақты скриншотты өз SQL Server ортаңызда түсіріңіз.

## Бақылау SQL
```sql
USE UniversityDb;
SELECT * FROM dbo.Departments;
SELECT * FROM dbo.Teachers;
SELECT * FROM dbo.__EFMigrationsHistory;
```

## GitHub
GitHub-та `UniversityDbApp` атты жаңа Public репозиторий құрыңыз; осы папка мазмұнын жүктеңіз. GitHub сілтемесін есепке енгізіңіз.

**Ескерту:** Бұл архивтегі код дайындалған, бірақ осы ортада .NET/SQL Server болмағандықтан compile, миграцияны орындау және сервердегі кестелерді растау мүмкін болмады.
